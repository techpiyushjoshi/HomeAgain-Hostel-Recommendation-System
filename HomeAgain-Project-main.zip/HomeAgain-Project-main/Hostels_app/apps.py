from django.apps import AppConfig


class HostelsAppConfig(AppConfig):
    name = 'Hostels_app'